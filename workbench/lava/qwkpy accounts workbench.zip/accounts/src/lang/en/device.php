<?php

return array(
    /*
      |--------------------------------------------------------------------------
      | Vehicle Language Lines
      |--------------------------------------------------------------------------
     */
    'api' => array(
        'getSingle' => 'Device :field :value found.',
        'getAll' => 'Your Devices list',
        'create' => 'Device :field :value created',
        'update' => 'Device :field :value updated',
        'delete' => 'Device :field :value deleted',
    )
);
