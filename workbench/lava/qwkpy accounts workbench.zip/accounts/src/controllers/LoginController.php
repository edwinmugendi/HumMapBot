<?php
namespace Lava\Accounts;

/**
 * S# LoginController() function
 * Account controller
 * @author Edwin Mugendi
 */
class LoginController extends AccountsBaseController {

    //Controller
    public $controller = 'login';
    
}

//E# LoginController() function