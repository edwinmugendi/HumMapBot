<?php

namespace Lava\Accounts;

/**
 * S# AccountsBaseController() function
 * Accounts Base Controller
 * @author Edwin Mugendi
 */
class AccountsBaseController extends \BaseController {

    //Package
    public $package = 'accounts';

}

//E# AccountsBaseController() function