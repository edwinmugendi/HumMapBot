<?php

return array(
    /*
      |--------------------------------------------------------------------------
      | Third Party Credentials
      |--------------------------------------------------------------------------
      |
     */
    'facebook' => array(
        'appId' => '291512857637270',
        'appSecret' => '1c4a3dcef631bf5104ed9f8239bfb139',
        "scope" => "email,user_birthday"
    ),
    'carweb' => array(
        'username' => 'motwbudd',
        'password' => '101212',
        'clientref' => 'test',
        'clientdescription' => 'test',
        'key' => 'mw10bd12',
        'version' => ' 0.31.1',
        'url' => 'https://www1.carwebuk.com/CarweBVRRB2Bproxy/carwebvrrwebservice.asmx/strB2BGetVehicleByVRM'
    )
);
