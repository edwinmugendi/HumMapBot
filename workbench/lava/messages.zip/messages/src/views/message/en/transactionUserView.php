<p>Dear <? echo $viewData['name']; ?>,</p>
<p></p>
