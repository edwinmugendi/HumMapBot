<p>Dear <?php echo $viewData['name']; ?>,</p>
<p>You have recently created an account on <?php echo $viewData['productName'];?> using this email address: <?php echo $viewData['email']; ?></p>

<p>Kindly click on the link below (or copy and paste the link (URL) onto your browser) to activate your account and enjoy all our cool features <?php echo $viewData['productName'];?> has to offer:</p>

<p><?php echo $viewData['url']; ?></p>

<p>If you didn't create an account on <?php echo $viewData['productName'];?> kindly ignore this email or consider creating one.</p>
