<?php
namespace Lava\Messages;

/**
 * S# MessagesBaseController() function
 * Messages Base Controller
 * @author Edwin Mugendi
 */
class MessagesBaseController extends \BaseController {

    //Package
    public $package = 'messages';

}

//E# MessagesBaseController() function