<?php

return array(
    'communication' => array(
        'welcome' => array(
            'urgent' => 1,
            'log' => 1,
        ),
        'resetPassword' => array(
            'urgent' => 1,
            'log' => 1,
        ),
        'transaction' => array(
            'urgent' => 1,
            'log' => 1,
        ),
    )
);
