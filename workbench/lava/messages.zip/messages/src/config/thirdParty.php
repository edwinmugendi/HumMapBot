<?php

return array(
    /*
      |--------------------------------------------------------------------------
      | Third Party Credentials
      |--------------------------------------------------------------------------
      |
     */
    'clickatell' => array(
        "apiId" => "3422899",
        "username" => "lavamsg",
        "password" => "OEfCOBESeVeBGN",
    )
);
