<?php

return array(
    /*
      |--------------------------------------------------------------------------
      | Third Party Credentials
      |--------------------------------------------------------------------------
      |
     */
    'clickatell' => array(
        "apiId" => "3480294",
        "username" => "lavasms",
        "password" => "MBKUAHMRaNTfKD",
    )
);
